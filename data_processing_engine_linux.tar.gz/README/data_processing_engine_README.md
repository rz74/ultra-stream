# High-Performance Data Processing Engine – Project Overview

This project implements a **low-latency UDP-to-TCP data processing engine** designed for real-time streaming data applications. The service consumes UDP multicast data streams, maintains multi-level data books per subject, calculates composite scores using configurable algorithms, and forwards processed results via TCP. Network byte order is adopted system-wide for optimal performance.

---

## Key Components

### CompositeScoreCalculator
The `CompositeScoreCalculator` is a configurable computational engine that processes multi-level data updates. It performs weighted calculations over demand/supply levels to generate composite scores. The algorithm is designed to be:
- **Fast**: Sub-millisecond processing per message
- **Scalable**: Handles multiple data subjects simultaneously  
- **Generic**: Adaptable to various data processing scenarios

### DataBook Management
The `DataBook` system maintains real-time state for each data subject:
- **Multi-level tracking**: Up to 10 levels of demand/supply data
- **Efficient updates**: Delta-based processing for minimal overhead
- **Memory optimized**: Compact data structures for cache efficiency

---

## Project Structure

```
data_processing_engine/
├── CMakeLists.txt                    # CMake build configuration for the entire project
├── run_full_pipeline.sh             # Master script to build, generate test vectors, and run full performance test
├── .vscode/
│   └── settings.json                # VSCode project-specific settings
├── build/                           # CMake-generated build artifacts (binaries, objects, CMake files)
│   ├── bin/
│   │   ├── data_processing_service # Main executable - high-performance data processing engine
│   │   ├── tcp_receiver            # Test TCP server to capture processed data outputs
│   │   ├── test_all                # Integration test runner and performance validator
│   │   └── udp_packet_generator    # Test data generator for load testing
│   └── ...                         # Intermediate object files, dependency tracking, etc.
├── include/
│   ├── logger.hpp                  # High-performance logging with microsecond timestamps
│   ├── composite_score_calculator.hpp # CompositeScoreCalculator for data aggregation algorithms
│   ├── data_book.hpp              # DataBook classes to manage multi-level data state per subject
│   ├── parser_utils.hpp           # Binary protocol parsing and endianness utilities
│   ├── process_packet_core.hpp    # Core pipeline: parse message → update data → calculate → transmit
│   ├── tcp_sender.hpp             # TcpSender class for reliable result transmission
│   ├── types.hpp                  # Shared type definitions: DataLevel, ProcessedMessage, CompositeScoreMessage
│   └── udp_receiver.hpp           # UdpReceiver for high-efficiency multicast data ingestion
├── logs/
│   ├── tcp_stderr.log             # Error logs captured from tcp_receiver during testing
│   └── tcp_stdout.log             # Output logs captured from tcp_receiver during testing
├── src/
│   ├── logger.cpp                 # Implementation of microsecond-precision logging
│   ├── main.cpp                   # Application entry: sets up multicast ingestion, data processing, TCP output
│   ├── composite_score_calculator.cpp # Implementation of configurable scoring algorithms
│   ├── data_book.cpp              # Implements DataBook update logic and demand/supply state management
│   ├── parser_utils.cpp           # Binary message parsing with network byte order handling
│   ├── tcp_sender.cpp             # TCP socket management and message transmission
│   └── udp_receiver.cpp           # Multicast receive loop with user-provided callback dispatch
├── test/
│   ├── evaluate_results.py        # Python analytics engine: generates performance dashboard from timing data
│   ├── tcp_receiver.cpp           # TCP test server to capture and validate processed outputs
│   ├── test_all.cpp               # Comprehensive integration test with latency measurement
│   └── udp_packet_generator.cpp   # Load test generator: produces realistic UDP data streams
├── test_data/
│   ├── input_packets.bin          # Binary test data stream for system validation
│   ├── input_packets.csv          # Human-readable representation of test data
│   └── input_summary.csv          # Test case summary with expected processing behavior
├── test_results/
│   ├── latency_report.html        # Interactive performance dashboard with histograms and statistics
│   ├── latency_trace.csv          # Microsecond-precision timing data for each processed message
│   ├── tcp_sent.csv               # Actual output messages transmitted via TCP (validation data)
│   └── test_all.log               # Complete test execution log with performance metrics
├── tools/
│   ├── generate_test_vectors.cpp  # Test data generator: creates realistic data patterns for validation
│   └── udp_generator.cpp          # Alternative UDP injection utility for custom test scenarios
├── archive/                        # Additional utilities and experimental components
└── README/
    └── data_processing_engine_README.md # This file - comprehensive project documentation
```

---

### Testing and Performance Validation
The system includes comprehensive performance testing:
- **Latency measurement**: Microsecond-precision timing throughout the pipeline
- **Load testing**: Configurable packet generation with realistic data patterns
- **Performance reporting**: Automated HTML dashboard generation
- **Stress testing**: High-frequency data stream simulation

### Environment Requirements
All tests were run under WSL with cross-platform compatibility.

> If you encounter errors such as `bad interpreter: No such file or directory`, it's likely due to Windows-style line endings (`^M`). To fix this, you can run:
>
> ```bash
> dos2unix run_full_pipeline.sh
> ```

This conversion solves the issue of scripts not executing properly in WSL environments.

### Performance Analytics
A comprehensive **performance report** is generated using the Python analytics script `evaluate_results.py` in the `test/` directory. The resulting analysis includes:
- **Latency distributions** per message complexity
- **Throughput metrics** across different load patterns  
- **Performance histograms** and statistical summaries
- **Interactive dashboard** saved as `latency_report.html`

---

## Architecture Highlights

### Network Processing
- **UDP Multicast Input**: High-efficiency packet reception with minimal overhead
- **TCP Output Streaming**: Reliable delivery of processed results
- **Zero-copy optimizations**: Direct memory access patterns where possible

### Data Pipeline
1. **UDP Reception**: Raw packet capture and validation
2. **Message Parsing**: Binary protocol decoding with endianness handling
3. **Data Book Updates**: Real-time state management per subject
4. **Composite Calculation**: Configurable scoring algorithms
5. **TCP Transmission**: Formatted result delivery

### Performance Characteristics
- **Latency**: Sub-millisecond end-to-end processing
- **Throughput**: 1000+ messages/second sustained
- **Memory**: Efficient data structures with minimal allocation
- **CPU**: Optimized algorithms with cache-friendly access patterns

---

## Build and Execution

### Quick Start

**Prerequisites**: This project uses Linux-specific networking libraries and requires a Linux environment. On Windows, use WSL (Windows Subsystem for Linux).

#### On Linux or WSL:
```bash
# Ensure required tools are installed
sudo apt update
sudo apt install build-essential cmake python3 python3-pip

# Install Python dependencies
pip3 install pandas matplotlib

# Fix line endings (important for WSL users)
dos2unix run_full_pipeline.sh

# Make script executable
chmod +x run_full_pipeline.sh

# Clean any existing build cache (prevents CMake path conflicts)
rm -rf build/

# Build and run complete test suite
./run_full_pipeline.sh

# Note: The script will prompt if you want to rebuild the binaries
# - Choose 'y' for first run or after making code changes
# - Choose 'n' to skip rebuild and use existing binaries

# Manual build
mkdir -p build && cd build
cmake .. && make

# Run individual components  
./build/bin/data_processing_service
./build/bin/test_all
```

#### On Windows (WSL Setup):
```bash
# First install WSL and Ubuntu from Microsoft Store if not already installed
# Open WSL terminal and navigate to your project directory
cd /mnt/c/path/to/your/project

# Install dependencies
sudo apt update
sudo apt install build-essential cmake python3 python3-pip dos2unix
pip3 install pandas matplotlib

# Clean any existing build cache and continue with Linux commands above
```

### Configuration
The system supports runtime configuration for:
- **Network parameters**: Multicast addresses, TCP ports
- **Data subjects**: Number and ID ranges
- **Processing algorithms**: Scoring calculation methods
- **Performance tuning**: Buffer sizes, thread counts

### Development Notes
Before committing to version control, clean build artifacts to prevent exposing local paths:
```bash
rm -rf build/ test_results/ logs/
```

---

## Applications

This generic data processing engine is suitable for:
- **Real-time analytics**: Stream processing, data aggregation, metric calculation
- **IoT data streams**: Sensor aggregation, real-time analytics
- **Network monitoring**: Traffic analysis, performance metrics
- **Scientific computing**: Real-time data reduction, signal processing
- **Gaming/simulation**: Live event processing, state synchronization

---

## Final Notes

- The main executable `data_processing_service` is built via `CMakeLists.txt` and orchestrated using shell scripts
- `run_full_pipeline.sh` provides end-to-end testing: build, data generation, and performance analysis
- Only unique composite score updates per subject are transmitted to optimize bandwidth
- All components are designed for minimal latency and maximum throughput

This architecture demonstrates modern C++ best practices for high-performance data processing, suitable for both academic research and industrial applications.
