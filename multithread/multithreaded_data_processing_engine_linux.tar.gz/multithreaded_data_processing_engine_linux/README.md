# Multithreaded Data Processing Engine

A high-performance, multithreaded C++ service for real-time UDP data stream processing with low-latency TCP output. This distribution includes a complete, portable implementation using Boost.Asio for asynchronous networking.

## Architecture

### Threading Model
- **Main Thread**: Service lifecycle coordination
- **UDP Receiver Thread**: Asynchronous UDP multicast reception  
- **Worker Thread Pool**: Parallel data processing (auto-scaled to CPU cores)
- **TCP Sender Thread**: Low-latency TCP output transmission
- **Statistics Thread**: Real-time performance monitoring

### Data Flow
1. **UDP Reception**: Multicast packets received asynchronously
2. **Queue Management**: Thread-safe packet queuing with condition variables
3. **Parallel Processing**: Worker threads process data concurrently
4. **Thread-Safe Updates**: Mutex-protected data book modifications
5. **Real-time Output**: Immediate composite score calculation and TCP transmission
6. **Performance Tracking**: Continuous latency and throughput monitoring

## Quick Start

### Basic Usage
```bash
# Start with default settings (239.255.0.1:30001)
./DataProcessingService

# Specify custom multicast address and port
./DataProcessingService 239.255.0.1 12345
```

### Test with Sample Data
```bash
# Send test data packets (in another terminal)
echo "1001,B,0,100.50,1000" | nc -u 239.255.0.1 12345
echo "1001,S,0,100.55,500" | nc -u 239.255.0.1 12345
```

### Monitor Performance
The service provides real-time statistics:
- Packet reception rates
- Processing latency distribution  
- Thread utilization metrics
- Memory usage statistics

## Data Format

### Input Format (UDP)
```
subject_id,side,level,value,volume
```

**Example:**
```
1001,B,0,100.50,1000    # Demand level 0: value=100.50, volume=1000
1001,S,1,100.75,750     # Supply level 1: value=100.75, volume=750
```

**Fields:**
- `subject_id`: Data subject identifier (integer)
- `side`: B=Demand, S=Supply
- `level`: Level index (0-9)
- `value`: Numeric value (decimal)
- `volume`: Volume amount (integer)

### Output Format (CSV)
```csv
subject_id,composite_score
1001,100.625
1002,95.123
```

## Performance Characteristics

### Latency
- **Processing**: Sub-millisecond data book updates
- **End-to-End**: Complete packet-to-output pipeline < 1ms
- **Thread Overhead**: Minimal with efficient synchronization

### Throughput  
- **Packet Rate**: >100,000 packets/second sustained
- **Concurrent Subjects**: Thousands with maintained performance
- **Memory Usage**: Efficient data structures, minimal allocation

### Scalability
- **CPU Utilization**: Automatic scaling to available cores
- **Thread Pool**: Dynamic worker count based on hardware
- **Memory Footprint**: Constant memory usage regardless of load

## Thread Safety

All shared data structures use appropriate synchronization:

### Synchronization Primitives
- **std::mutex**: Data book protection
- **std::condition_variable**: Worker thread coordination  
- **std::atomic**: Performance counters and control flags
- **Lock-free Queues**: High-performance packet buffering

### Concurrency Design
- **Reader-Writer Access**: Optimized for concurrent reads
- **Minimal Lock Scope**: Short critical sections
- **Deadlock Prevention**: Consistent lock ordering
- **Exception Safety**: RAII and proper cleanup

## Configuration

### Runtime Parameters
```bash
./DataProcessingService [multicast_address] [port]
```

### Environment Variables
- `DATA_PROCESSING_THREADS`: Override auto-detected thread count
- `DATA_PROCESSING_OUTPUT`: Custom output file path
- `DATA_PROCESSING_LOG_LEVEL`: DEBUG, INFO, WARN, ERROR

### Build-Time Configuration
- Thread pool sizing in source code
- Buffer sizes for UDP/TCP operations  
- Timeout values for network operations

## Monitoring & Debugging

### Built-in Monitoring
- Real-time packet processing statistics
- Thread utilization reporting
- Memory usage tracking
- Network performance indicators

### Debug Output
Enable with:
```bash
export DATA_PROCESSING_LOG_LEVEL=DEBUG
./DataProcessingService
```

### Performance Profiling
The service outputs detailed timing information for:
- Packet parsing latency
- Data book update times
- Composite score calculation duration
- Network transmission delays

## System Requirements

### Minimum Requirements
- **OS**: Linux (64-bit)
- **CPU**: 2 cores (4+ recommended)
- **RAM**: 512MB (2GB+ for high throughput)
- **Network**: UDP multicast support

### Recommended Setup
- **CPU**: 8+ cores for maximum parallelism
- **RAM**: 4GB+ for large-scale deployments
- **Network**: Low-latency network infrastructure
- **Storage**: SSD for log files and output

## Troubleshooting

### Common Issues

**Multicast Reception Problems:**
```bash
# Check multicast routing
ip route show table local type multicast

# Verify interface configuration  
ip maddress show
```

**Performance Issues:**
```bash
# Monitor CPU usage
htop

# Check network buffer sizes
cat /proc/sys/net/core/rmem_max
```

**Thread Contention:**
```bash
# Monitor thread activity
perf record -g ./DataProcessingService
perf report
```

### Log Analysis
Monitor service logs for:
- Thread startup/shutdown events
- Network connection status
- Processing rate statistics
- Error conditions and recovery

## Technical Implementation

### Key Components
- **AsyncUDPReceiver**: Boost.Asio-based UDP multicast handling
- **ThreadSafeDataBook**: Concurrent data structure with fine-grained locking
- **CompositeScoreCalculator**: Weighted value computation engine
- **WorkerThreadPool**: Dynamic thread management and load balancing

### Design Patterns
- **Producer-Consumer**: UDP receiver feeds worker threads
- **Thread Pool**: Configurable worker thread management
- **Observer**: Statistics monitoring and reporting
- **RAII**: Automatic resource management

## License

MIT License - See LICENSE file for complete terms.

## Support

For technical questions or deployment assistance:
- Review logs for diagnostic information
- Check system requirements and configuration
- Verify network connectivity and multicast setup
- Monitor resource usage and performance metrics
