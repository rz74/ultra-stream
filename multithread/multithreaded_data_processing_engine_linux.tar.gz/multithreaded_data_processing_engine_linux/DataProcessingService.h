﻿// DataProcessingService.h: Standard system include files
// or project-specific include files.

#pragma once

#include <iostream>

// TODO: Include other headers needed by the program here.
