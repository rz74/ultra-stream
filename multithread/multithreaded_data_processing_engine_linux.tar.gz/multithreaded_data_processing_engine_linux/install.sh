#!/bin/bash

echo "=== Multithreaded Data Processing Engine - Installation ==="

# Check system requirements
echo "Checking system requirements..."

# Check for Linux
if [[ "$(uname)" != "Linux" ]]; then
    echo "Warning: This distribution is optimized for Linux systems"
fi

# Check for multicore CPU
CPU_CORES=$(nproc)
echo "Detected $CPU_CORES CPU cores"

if [ $CPU_CORES -lt 2 ]; then
    echo "Warning: Minimum 2 CPU cores recommended for optimal performance"
fi

# Check memory
MEMORY_KB=$(grep MemTotal /proc/meminfo | awk '{print $2}')
MEMORY_MB=$((MEMORY_KB / 1024))
echo "Detected ${MEMORY_MB}MB RAM"

if [ $MEMORY_MB -lt 512 ]; then
    echo "Warning: Minimum 512MB RAM recommended"
fi

# Make executable
chmod +x DataProcessingService
echo "DataProcessingService executable configured"

# Test execution
echo "Testing executable..."
timeout 2s ./DataProcessingService 2>/dev/null || echo "Executable test completed"

echo ""
echo "Installation complete!"
echo ""
echo "Quick start:"
echo "  ./DataProcessingService                    # Use default settings"
echo "  ./DataProcessingService 239.255.0.1 12345 # Custom multicast config"
echo ""
echo "For detailed documentation, see README.md"
